Graveyard Keeper 2 — Mods
==========================

This folder is for community content loaded from disk.

The game also looks in the folder next to the executable, and in subscribed
Steam Workshop items.

Press Shift+F10 in the game to create example folders and reload mods.

workshop.json in this folder enables the Steam Workshop Creator (Shift+F11).
It is created automatically. Set "workshopCreatorMode" to true to use it.

Any folder whose name starts with ~ is ignored (easy way to disable a pack).

Current categories:
  Languages/   extra languages for the in-game language selector
               See Languages/README.txt.
